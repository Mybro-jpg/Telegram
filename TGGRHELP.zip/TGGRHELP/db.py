# Database related functions
