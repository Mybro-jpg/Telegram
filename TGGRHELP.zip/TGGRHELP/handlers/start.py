# start.py handler
