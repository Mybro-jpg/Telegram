# stats.py handler
